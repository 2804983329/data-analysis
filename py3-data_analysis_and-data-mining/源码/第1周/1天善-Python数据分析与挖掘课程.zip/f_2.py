a=10
b=1
if(a>9):
    print(a)
    if(b==9):
        print(b)
elif(a<10):
    print("abc")
